#include <iostream>
#include <fstream>
#include <string>

using namespace std;

struct Kontak {
    string nama;
    string nomor_telepon;
};

void membersihkan_console() {
    // Membersihkan console, hanya berlaku di Windows OS
    // Fungsi yang digunakan untuk memanggil command dari os
    system("cls");
}

void menambahkan_kontak() {
    Kontak kontak; // Membuat instance dari struct Kontak

    /*
    * ofstream merupakan class dari library fstream yang digunakan untuk menulis pada file
    * 
    * ios:app merupakan mode akses untuk membuka file dan menulis file
    * Jika menambah teks di mode ini akan menambahkan teks tersebut di akhir file
    */
    ofstream daftar_kontak("daftar_kontak.txt", ios::app);

    cout << "----------------" << endl;
    cout << "| Tambah Kontak |" << endl;
    cout << "----------------" << endl;

    // Cek file yang akan ditulis dan menulis file
    if (daftar_kontak.is_open()) {
        cout << "----------------------" << endl;
        cout << "Masukkan nama kontak" << endl;
        cout << "> Input: ";
        cin.ignore();
        getline(cin, kontak.nama);
        cout << "" << endl;

        cout << "Masukkan nomor telepon" << endl;
        cout << "> Input: ";
        getline(cin, kontak.nomor_telepon);
        cout << "" << endl;

        daftar_kontak << "Nama: " << kontak.nama << endl;
        daftar_kontak << "Nomor: " << kontak.nomor_telepon << endl;
        daftar_kontak << "" << endl;

        membersihkan_console();
        cout << "-----------------------" << endl;
        cout << "| Kontak ditambahkan! |" << endl;;
        cout << "-----------------------" << endl;
        daftar_kontak.close();
    }
    else {
        cout << "-----------------------------------------" << endl;
        cout << "| Gagal membuka file untuk penyimpanan  |" << endl;
        cout << "-----------------------------------------" << endl;
    }
}

void menampilkan_daftar_kontak() {
    cout << "----------------" << endl;
    cout << "| Daftar Kontak |" << endl;
    cout << "----------------" << endl;
    cout << "" << endl;

    // ifstream merupakan class dari library fstream yang digunakan untuk membaca dari file
    ifstream file("daftar_kontak.txt");

    // Digunakan nanti untuk membaca setiap baris dari file daftar_kontak.txt
    string setiap_baris;

    // Untuk cek nanti jika daftar kontaknya kosong
    bool jika_kosong = true;

    if (file.is_open()) {
        while (getline(file, setiap_baris)) {
            cout << setiap_baris << endl;
            jika_kosong = false;
        }

        file.close();
    }
    else {
        cout << "-----------------------------------------" << endl;
        cout << "| Gagal membuka file untuk menampilkan  |" << endl;
        cout << "-----------------------------------------" << endl;
    }

    // Cek jika daftar_kontaknya kosong
    if (jika_kosong) {
        membersihkan_console();
        cout << "-----------------------------------------" << endl;
        cout << "| Anda belum menambahkan seseorang ke   |" << endl;
        cout << "| dalam kontak Anda                     |" << endl;
        cout << "-----------------------------------------" << endl;
    }
}

void menghapus_kontak() {
    cout << "----------------" << endl;
    cout << "| Hapus Kontak |" << endl;
    cout << "----------------" << endl;
    cout << "" << endl;

    string input_pengguna;

    cout << "-----------------------------------------------" << endl;
    cout << "Masukkan nama kontak yang ingin Anda hapus" << endl;
    cout << "> Input: ";
    cin >> input_pengguna;


    /* 
    * (agar tidak lupa saat menjelaskan)
    * ofstream merupakan class dari library fstream yang digunakan untuk menulis pada file
    * ifstream merupakan class dari library fstream yang digunakan untuk membaca dari file
    */

    ifstream file_input("daftar_kontak.txt");
    ofstream file_output("penyimpanan_sementara.txt");

    // Digunakan nanti untuk membaca setiap baris dari file daftar_kontak.txt
    string baris_nama, baris_nomor;
    bool ketemu = false;

    if (file_input.is_open() && file_output.is_open()) {
        while (getline(file_input, baris_nama) && getline(file_input, baris_nomor)) {

            /*
            * find merupakan fungsi yang digunakan untuk mencari substring dari sebuah string
            * string::npos merupakan representasi nilai kosong atau tidak ditemukan
            * 
            * refrensi :
            * https://cplusplus.com/reference/string/string/npos/
            * https://cplusplus.com/reference/string/string/find/
            */

            // Cek apakah nama atau nomor telepon cocok dengan input
            if (baris_nama.find(input_pengguna) != string::npos || 
                baris_nomor.find(input_pengguna) != string::npos) {

                ketemu = true;
                continue; // Lewati penulisan kontak yang cocok dengan input
            }
            
            file_output << baris_nama << endl << baris_nomor << endl;
        }

        file_output.close();
        file_input.close();

        if (ketemu) {
            // Fungsi remove digunakan untuk menghapus sebuah file dengan menerima nama filenya
            remove("daftar_kontak.txt");

            // Fungsi rename bisa untuk mengubah nama file atau file itu sendiri
            // Dalam kasus ini temp.txt diganti namanya menjadi daftar_kontak.txt
            rename("penyimpanan_sementara.txt", "daftar_kontak.txt");

            membersihkan_console();
            cout << "---------------------------" << endl;
            cout << "| Kontak berhasil dihapus |" << endl;
            cout << "---------------------------" << endl;
        }
        else {
            cout << "--------------------------" << endl;
            cout << "| Kontak tidak ditemukan |" << endl;
            cout << "--------------------------" << endl;
            remove("temp.txt");
        }
    }
    else {
        cout << "---------------------------------------------" << endl;
        cout << "| Gagal membuka file untuk menghapus kontak |" << endl;
        cout << "---------------------------------------------" << endl;
    }
}

int main() {
    membersihkan_console();
    cout << "----------" << endl;
    cout << "| KONTAK |" << endl;
    cout << "----------" << endl;

    int pilih_opsi;

    while (true) {
        cout << "---------------------------" << endl;
        cout << "Masukkan Opsi Yang Tersedia" << endl;
        cout << "" << endl;
        cout << "(1) Tambah kontak" << endl;
        cout << "(2) Hapus kontak" << endl;
        cout << "(3) Daftar Kontak" << endl;
        cout << "(4) Keluar program" << endl;
        cout << "---------------------------" << endl;
        cout << "" << endl;

        cout << "> Input: ";
        cin >> pilih_opsi;

        switch (pilih_opsi) {
        case 1:
            membersihkan_console();
            menambahkan_kontak();
            break;
        case 2:
            membersihkan_console();
            menghapus_kontak();
            break;
        case 3:
            membersihkan_console();
            menampilkan_daftar_kontak();
            break;
        case 4:
            char opsi_keluar;
            membersihkan_console();
            cout << "------------------------------------------" << endl;
            cout << "| Apakah Anda Yakin Keluar dari Program? |" << endl;
            cout << "| (y/Y) Untuk keluar dari program        |" << endl;
            cout << "| (n/N) Untuk tetap berada di program    |" << endl;
            cout << "------------------------------------------" << endl;
            cout << "" << endl;

            cout << "> Input: ";
            cin >> opsi_keluar;

            if (opsi_keluar == 'y' || opsi_keluar == 'Y') {
                membersihkan_console();

                // exit merupakan fungsi yang digunakan untuk menghentikan program
                // Dapat menerima 2 nilai (0, 1)
                // 0 = EXIT_SUCCES, 1 = EXIT_FAILURE
                exit(0);
            }
            else if (opsi_keluar == 'n' || opsi_keluar == 'N') {
                membersihkan_console();
                cout << "----------" << endl;
                cout << "| KONTAK |" << endl;
                cout << "----------" << endl;
            }
            else {
                membersihkan_console();
                cout << "-------------------------------------" << endl;
                cout << "| Opsi Tidak Valid                  |" << endl;
                cout << "| Mohon Masukkan Opsi Yang Tersedia |" << endl;
                cout << "-------------------------------------" << endl;
            }
            break;
        default:
            membersihkan_console();
            cout << "-------------------------------------" << endl;
            cout << "| Opsi Tidak Valid                  |" << endl;
            cout << "| Mohon Masukkan Opsi Yang Tersedia |" << endl;
            cout << "-------------------------------------" << endl;
        }
    }

    return 0;
}